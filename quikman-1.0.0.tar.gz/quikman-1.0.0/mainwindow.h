#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTreeView>
//#include <QWebView>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QProcess>
#include <QStandardItemModel>
#include <QCheckBox>
#include <QPushButton>
#include <QLineEdit>
#include <QTextStream>

 class QAction;
 class QMenu;
 class QPlainTextEdit;

 class MainWindow : public QMainWindow
 {
     Q_OBJECT

 public:
     MainWindow(QApplication *);
     void loadModels();
     void loadConfig();
     void loadDefaultManual();
     void lookupManual( const QString &name );

     static QStringList     manpaths;
     static QStringList     suffixes;
     static QStringList     msuffixes;
     static QTextStream     cout;

 protected:
     void closeEvent(QCloseEvent *event);

 private slots:
     bool rebuildDB();
     void saveModels();
     void clearRecent();
     void clearHistory();
     void openManualFromAll(const QModelIndex &);
     void openManualFromHistory(const QModelIndex &);
     void openManualFromRecent(const QModelIndex &);
     void doNothing();
     void pathSetting();
     void about();
//     void zoomIn();
//     void zoomOut();
     void openManLink( const QUrl & url );
     void bSearch();
     void fSearch();
     void searchClear();
     //void finExeCmd(int exitcode);
     //void startExeCmd();

 private:
     void createActions();
     void createMenus();
     void createToolBar();
     void createDockingWindow();
     void createStatusBar();
     void createCentralWidget();

     void setHeaderLabels();


     //void addToRecent(const QString &name, const QString &section, const QString &pathid);
     void addUniqueToRecent(const QString &name, const QString &section, const QString &pathid, const QDateTime &date, bool append = false);
     void addUniqueToHistory(const QString &name, const QString &section, const QString &pathid, const QDateTime &date, bool append = false);
     void addToAll(const QString &name, const QString &section, const QString &pathid);
     QString *dereferenceManual ( const QString &name, const QString &section , const QString &pathid);
     void viewManual(const QString &name, const QString &section, const QString &pathid);
     void readHtml( const QString &htmlFile, QString &data );
     void loadHtml( const QString & htmlFile );
     void loadSearch( QList<QStandardItem *> * );
     bool executeCmd( const QString & cmd , const QString &output);
     void getKeyValue( const QString & line, QString &key , QString &value );

     QVBoxLayout    *vbox;
     QTextDocument  *manTextDoc;
     QTextEdit      *manText;
     QWidget        *searchWidget;
     bool            recentGood;


     QString appName;
     QString currentName;
     QString currentSection;
     QString currentPathid;
     QApplication *app;
     QProcess *p ;
     QMenu *fileMenu;
     //QMenu *editMenu;
     //QMenu *openMenu;
     QMenu *optMenu;
     QMenu *helpMenu;
//     QToolBar *zToolBar;

     QAction *rebuildDbAct;
     QAction *saveRecentAct;
     QAction *clearRecentAct;
     QAction *clearHistoryAct;
     QAction *exitAct;
     QAction *fexitAct;

//     QAction *zOutAct;
     QAction *aboutAct;
     QAction *searchAct;

     QTabWidget  *notebook;

     QStandardItemModel *rModel;
     QStandardItemModel *hModel;
     QStandardItemModel *aModel;

     QTreeView *sList;
     QTreeView *hList;
     QTreeView *aList;

     QCheckBox   *sCase;
     QCheckBox   *sWords;
     QCheckBox   *sRegex;
     QLineEdit   *sText;
 };

 #endif
