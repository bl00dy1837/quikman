#include <QApplication>
#include <QDir>
#include "mainwindow.h"
#include "defines.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QDir *dir= new QDir();
    if ( ! dir->exists( QDir::homePath() + QString("/") + QString(QUIKMAN_DIR) ) ) {
        dir->mkdir(QDir::homePath() + QString("/") + QString(QUIKMAN_DIR) );
    }
    if ( ! dir->exists( QDir::tempPath() + QString("/") + QString(QUIKMAN_DIR) ) ) {
        dir->mkdir(QDir::tempPath() + QString("/") + QString(QUIKMAN_DIR) );
    }
    delete dir;
    MainWindow mainWin(&app);
    mainWin.loadConfig();
    mainWin.loadModels();


    if ( argc >= 2 ){
        mainWin.lookupManual( QString(argv[1]) );
    } else {
        mainWin.loadDefaultManual();
    }
    mainWin.show();
    return app.exec();
}
