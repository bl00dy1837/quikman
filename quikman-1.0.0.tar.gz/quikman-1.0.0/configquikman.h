#ifndef CONFIG__QUIKMAN__H__
#define CONFIG__QUIKMAN__H__

#define  QUIKMAN_PROGRAM    "QUIKMAN"
#define  QUIKMAN_ABOUT      "A replacement for xman utility. A quicker and an easier way to view the manual pages, complete with ability to open compressed (gz'd, bz2'd, lzma'd and Z'd) manuals and referenced manuals. Its also a brilliant learning tool for commands and library/system functions."
#define  QUIKMAN_REQUIRES   "Gzip, Bzip2, Lzma, Man-1.6f"
#define  QUIKMAN_PROVIDES   "quikman and compressman"


#define  QUIKMAN_AUTHOR              "Author: Anoop Kumar Narayanan "
#define  QUIKMAN_COPYRIGHT           "Copyright (c) 2009-* Anoop Kumar Narayanan \r\nAll rights reserved."
#define  QUIKMAN_VERSION_MAJOR       1
#define  QUIKMAN_VERSION_MINOR       0
#define  QUIKMAN_VERSION_REVISION    0


#endif
