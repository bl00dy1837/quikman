#ifndef DEFINES__QUIKMAN__H__
#define DEFINES__QUIKMAN__H__

#define  QUIKMAN_DIR       ".quikman"
#define  QUIKMAN_DB        ".all"
#define  QUIKMAN_RECENT    ".recent"
#define  QUIKMAN_HISTORY   ".history"
#define  MAN_CONFIG         "/etc/man.config"

#define  MAN_SUFFIX_GZIP   ".gz"
#define  MAN_SUFFIX_BZIP2  ".bz2"
#define  MAN_SUFFIX_LZMA   ".lzma"
#define  MAN_SUFFIX_Z      ".Z"

#define  MIN_MAN_SIZE      200
#define  LINEBREAK         "\r\n"
#define  DEFAULT_ZOOM      0.75
#define  DEFAULT_ZOOM_INC  0.05


#endif
